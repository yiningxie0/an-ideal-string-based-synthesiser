/*
  ==============================================================================

    MySynthesiser.h
    Created: 7 Mar 2020 4:27:57pm
    Author: Yining Xie modified from Tom Mudd's code

  ==============================================================================
*/

#pragma once

#include "MyOscillators.h"
#include "Delay.h"
#include "MakeString.h"
#include "TheSetOf5Strings.h"
#include "BasicOscs.h"
#include "Noise.h"
#include "Filters.h"

// ===========================
// ===========================
// SOUND
class MySynthSound : public juce::SynthesiserSound
{
public:
    bool appliesToNote      (int) override      { return true; }
    //--------------------------------------------------------------------------
    bool appliesToChannel   (int) override      { return true; }
};




// =================================
// =================================
// Synthesiser Voice - your synth code goes in here

/*!
 @class MySynthVoice
 @abstract struct defining the DSP associated with a specific voice.
 @discussion multiple MySynthVoice objects will be created by the Synthesiser so that it can be played polyphicially
 
 @namespace none
 @updated 2019-06-18
 */
class MySynthVoice : public juce::SynthesiserVoice
{
public:
    MySynthVoice() {}
    
    void init(float sampleRate)
    {
        // initialize envelop
        env.setSampleRate(sampleRate);
        
        juce::ADSR::Parameters envParams;
        envParams.attack = 0.5f;
        envParams.decay = 0.25f;
        envParams.sustain = 0.5f;
        envParams.release = 0.8f;
        env.setParameters(envParams);
        
        // get sample rate
        sr = getSampleRate();
        
        // initialize following class variables
        noise.setSampleRate(sampleRate);
        strings.setSampleRate(sampleRate);
        oscs.setSampleRate(sampleRate);
        filter.setSampleRate(sampleRate);
    }
    
    // get user set parameters
    void setParameterPointers(std::atomic<float>* detuneIn, std::atomic<float>* stringRN, std::atomic<float>* stringC, std::atomic<float>* stringK, std::atomic<float>* type, std::atomic<float>* dr, std::atomic<float>* delayforpluck, std::atomic<float>* g0, std::atomic<float>* g1, std::atomic<float>* g2, std::atomic<float>* fg, std::atomic<float>* oscsT, std::atomic<float>* oscsDe, std::atomic<float>* oscsG, std::atomic<float>* noiseG, std::atomic<float>* noiseT, std::atomic<float>* filterT, std::atomic<float>* filterCM, std::atomic<float>* filterCR, std::atomic<float>* filterLF, std::atomic<float>* filterq)
    {
        // parameters for strings
        stringDetuneAmount = detuneIn;
        stringResonanceNumber = stringRN;
        stringWaveVelocity = stringC;
        stringPluckPosition = stringK;
        strikeType = type;
        decayRate = dr;
        forPluckIsDelay = delayforpluck;
        centreStringGain = g0;
        detuneStringGain1 = g1;
        detuneStringGain2 = g2;
        freeGlide = fg;
        
        // parameters for oscs
        oscsType = oscsT;
        oscsGain = oscsG;
        oscsDetune = oscsDe;
        
        // parameters for noise
        noiseGain = noiseG;
        noiseType = noiseT;
        
        // parameters for filter
        filterType = filterT;
        filterCutoffMin = filterCM;
        filterCutoffRange = filterCR;
        filterQ = filterq;
        filterLfoFrequency = filterLF;
    }
    
    //--------------------------------------------------------------------------
    /**
     What should be done when a note starts

     @param midiNoteNumber
     @param velocity
     @param SynthesiserSound unused variable
     @param / unused variable
     */
    void startNote (int midiNoteNumber, float velocity, juce::SynthesiserSound*, int /*currentPitchWheelPosition*/) override
    {
        playing = true;
        ending = false;
        
        // get frequency from midi note
        freq = juce::MidiMessage::getMidiNoteInHertz(midiNoteNumber);
        
        // set string physical parameters
        strings.setFixedParam(*stringWaveVelocity, *stringPluckPosition, *stringResonanceNumber);
        
        // env on
        env.reset();
        env.noteOn();
    }
    //--------------------------------------------------------------------------
    /// Called when a MIDI noteOff message is received
    /**
     What should be done when a note stops

     @param / unused variable
     @param allowTailOff bool to decie if the should be any volume decay
     */
    void stopNote(float /*velocity*/, bool allowTailOff) override
    {
            allowTailOff = true;
            
            if (allowTailOff)
            {
                env.noteOff();
                ending = true;
            }
            else
            {
                clearCurrentNote();
                playing = false;
            }
        
    }
    
    //--------------------------------------------------------------------------
    /**
     The Main DSP Block: Put your DSP code in here
     
     If the sound that the voice is playing finishes during the course of this rendered block, it must call clearCurrentNote(), to tell the synthesiser that it has finished

     @param outputBuffer pointer to output
     @param startSample position of first sample in buffer
     @param numSamples number of smaples in output buffer
     */
    void renderNextBlock(juce::AudioSampleBuffer& outputBuffer, int startSample, int numSamples) override
    {
        if (playing) // check to see if this voice should be playing
        {
            
            // before DSP loop
            float* left = outputBuffer.getWritePointer(0);
            float* right = outputBuffer.getWritePointer(1);
            
            // set filter parameters
            filter.set(*filterType, *filterCutoffMin, *filterCutoffRange, *filterLfoFrequency, *filterQ);
            
            // get oscs parameters
            oscs.get(*oscsType, freq, *oscsDetune, *oscsGain);
            
            // get string gains and decat rate
            strings.getParam(*centreStringGain, *detuneStringGain1, *detuneStringGain2, *decayRate);
            
            // DSP loop
            for (int sampleIndex = startSample;   sampleIndex < (startSample+numSamples);   sampleIndex++)
            {
                // set strings frequencies
                strings.setFrequencies(freq, *stringDetuneAmount, *freeGlide);
                
                // get strike type
                type = *strikeType;
                
                // envelop output
                float envVal = env.getNextSample();
                
                // output of the useful classes
                float noiseVal = noise.process(*noiseType, *noiseGain);
                float soundOfString = strings.process(envVal, *strikeType, *forPluckIsDelay);
                float soundOfOscs = oscs.process();
                
                // track pluck status
                pluckTracker = strings.getTracker();
           
                // mix sounds and perform filter
                float mix = envVal * (noiseVal + soundOfOscs) + soundOfString;
                mix = filter.process(mix);
                
                // output value
                float currentSample = mix;
                
                // for each channel, write the currentSample float to the output
                left[sampleIndex] += currentSample;// ...
                right[sampleIndex] += currentSample;// ...
                
                
                // ending
                if (ending)
                {
                    // the pluck case
                    if (type == 0.0)
                    {
                        // when sound decays to unauditable
                        if (pluckTracker < 0.0001f)
                        {
                            clearCurrentNote();
                            playing = false;
                        }
                    }
                    // the continuous strike case
                    else
                        // depends on envelop
                        if (envVal < 0.0001f)
                    {
                        clearCurrentNote();
                        playing = false;
                    }
                }
            }
        }
    }
    //--------------------------------------------------------------------------
    void pitchWheelMoved(int) override {}
    //--------------------------------------------------------------------------
    void controllerMoved(int, int) override {}
    //--------------------------------------------------------------------------
    /**
     Can this voice play a sound. I wouldn't worry about this for the time being

     @param sound a juce::SynthesiserSound* base class pointer
     @return sound cast as a pointer to an instance of MySynthSound
     */
    bool canPlaySound (juce::SynthesiserSound* sound) override
    {
        return dynamic_cast<MySynthSound*> (sound) != nullptr;
    }
    //--------------------------------------------------------------------------
private:
    //--------------------------------------------------------------------------
    // Set up any necessary variables here
    /// Should the voice be playing?
    bool playing = false;
    bool ending = false;
    
    // parameters for strings
    std::atomic<float>* stringDetuneAmount;
    std::atomic<float>* stringResonanceNumber;
    std::atomic<float>* stringWaveVelocity;
    std::atomic<float>* stringPluckPosition;
    std::atomic<float>* strikeType;
    std::atomic<float>* decayRate;
    std::atomic<float>* forPluckIsDelay;
    std::atomic<float>* centreStringGain;
    std::atomic<float>* detuneStringGain1;
    std::atomic<float>* detuneStringGain2;
    std::atomic<float>* freeGlide;
    
    // parameters for oscs
    std::atomic<float>* oscsType;
    std::atomic<float>* oscsDetune;
    std::atomic<float>* oscsGain;
    
    // parameters for noise
    std::atomic<float>* noiseGain;
    std::atomic<float>* noiseType;
    
    // parameters for filters
    std::atomic<float>* filterType;
    std::atomic<float>* filterCutoffMin;
    std::atomic<float>* filterCutoffRange;
    std::atomic<float>* filterLfoFrequency;
    std::atomic<float>* filterQ;
    
    // envelop
    juce::ADSR env;
    
    // sample rate
    float sr;
    
    // frequency
    float freq;
  
    // pluck tracker
    float pluckTracker;
    
    //pluck type
    float type;
    
    // class variables
    TheSetOf5Strings strings;
    BasicOscs oscs;
    Noise noise;
    Filters filter;
};
