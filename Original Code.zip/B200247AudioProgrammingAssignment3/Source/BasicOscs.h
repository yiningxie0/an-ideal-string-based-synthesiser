/*
  ==============================================================================

    BasicOscs.h
    Created: 18 Dec 2022 11:17:34pm
    Author:  Yining Xie

  ==============================================================================
*/

#pragma once
#include "MyOscillators.h"

/**
 A class of basic oscillators with 4 types, each with 2 oscs of the same kind with a detune
 - sine oscillator
 - triangle oscillator
 - square oscillator
 - sawtooth oscillator
 out put the selected osc pairs
 */
class BasicOscs
{
public:
    /// empty destructor function
    ~BasicOscs(){}
    
    /**
     set sample rate
     
     @param sr samplerate in Hz
     */
    void setSampleRate(float sampleRate)
    {
        for (int i = 0; i < 2; i++)
        {
            sinOsc[i].setSampleRate(sampleRate);
            triOsc[i].setSampleRate(sampleRate);
            squareOsc[i].setSampleRate(sampleRate);
            phasor[i].setSampleRate(sampleRate);
        }
    }
    
    /**
     get and set osc type, frequency, detune frequency and gain
     
     @param type type of osc
     @param freq frequency
     @param detune detune frequency
     @param g gain
     */
    void get(float type, float freq, float detune, float g)
    {
        choice = type;
        gain = g;
        
        // set frequency for osc pairs
        for (int i = 0; i < 2; i++)
        {
            sinOsc[i].setFrequency(freq - i * detune);
            triOsc[i].setFrequency(freq - i * detune);
            squareOsc[i].setFrequency(freq - i * detune);
            phasor[i].setFrequency(freq - i * detune);
        }
    }
    
    /**
     return results according to user's selections
     */
    float process()
    {
        switch(choice){
            // sine osc
            case 0: {
                output = sinOsc[0].process() + sinOsc[1].process();
                break;
            }
                
            // triangle osc
            case 1: {
                output = triOsc[0].process() + triOsc[1].process();
                break;
            }
                
            // square osc
            case 2: {
                output = squareOsc[0].process() + squareOsc[1].process();
                break;
            }
                
            //sawtooth osc
            case 3: {
                output = phasor[0].process() + phasor[1].process();
                break;
            }
            default: {
                break;
            }
        }
        
        return gain * output;
    }
private:
    // oscs
    SinOsc sinOsc[2];
    TriOsc triOsc[2];
    SquareOsc squareOsc[2];
    Phasor phasor[2];
    
    // user's choice of type
    int choice;
    // output
    float output;
    // gain
    float gain;
};
