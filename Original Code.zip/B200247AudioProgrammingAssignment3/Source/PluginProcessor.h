/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "MySynthesiser.h"

//==============================================================================
/**
*/
class B200247AudioProgrammingAssignment3AudioProcessor  : public juce::AudioProcessor
                            #if JucePlugin_Enable_ARA
                             , public juce::AudioProcessorARAExtension
                            #endif
{
public:
    //==============================================================================
    B200247AudioProgrammingAssignment3AudioProcessor();
    ~B200247AudioProgrammingAssignment3AudioProcessor() override;

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    //==============================================================================
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    //==============================================================================
    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

private:
    
    juce::AudioProcessorValueTreeState parameters;
    
    // parameters for strings, as named or explained in the class
    std::atomic<float>* stringDetuneParam;
    std::atomic<float>* stringResonanceNumber;
    std::atomic<float>* stringWaveVelocity;
    std::atomic<float>* stringPluckPosition;
    std::atomic<float>* strikeType;
    std::atomic<float>* decayRate;
    std::atomic<float>* forPluckIsDelay;
    std::atomic<float>* centreStringGain;
    std::atomic<float>* detuneStringGain1;
    std::atomic<float>* detuneStringGain2;
    std::atomic<float>* freeGlide;
    
    // parameters for oscs, as named or explained in the class
    std::atomic<float>* oscsType;
    std::atomic<float>* oscsDetune;
    std::atomic<float>* oscsGain;
    
    // parameters for noise, as named or explained in the class
    std::atomic<float>* noiseGain;
    std::atomic<float>* noiseType;
    
    // parameters for filter, as named or explained in the class
    std::atomic<float>* filterType;
    std::atomic<float>* filterCutoffMin;
    std::atomic<float>* filterCutoffRange;
    std::atomic<float>* filterLfoFrequency;
    std::atomic<float>* filterQ;
    
    // decay and gain in left channel
    std::atomic<float>* leftDelayTime;
    std::atomic<float>* leftGain;
    
    // decay and gain in right channel
    std::atomic<float>* rightDelayTime;
    std::atomic<float>* rightGain;
    
    // parameters for reverb
    std::atomic<float>* reverbDryLevel;
    std::atomic<float>* reverbWetLevel;
    std::atomic<float>* reverbRoomSize;
    
    // set up delayline
    DelayLine delay[2];
    // include synth
    juce::Synthesiser synth;
    // sample rate
    float sr;
    // voice count
    int voiceCount = 30;
    // include reverb class
    juce::Reverb reverb;
    
    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (B200247AudioProgrammingAssignment3AudioProcessor)
};
