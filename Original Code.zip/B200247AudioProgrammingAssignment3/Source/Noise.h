/*
  ==============================================================================

    Noise.h
    Created: 18 Dec 2022 9:02:37pm
    Author:  Yining Xie

  ==============================================================================
*/

#pragma once
#include "MyOscillators.h"

/**
 A class of noise with 2 types
 - with highpass filter, that sounds noisier and can simulate moving of leaves, sound of waterfalls, or electronic noise
 - with lowpass filter, it sound quieter and more like sound of tide, wind in open air, etc.
 */
class Noise
{
public:
    
    /// empty destructor function
    ~Noise(){};
    
    /**
     set sample rate
     
     @param sr samplerate in Hz
     */
    void setSampleRate(float sr)
    {
        sampleRate = sr;
    }
    
    /**
     generate nosie
     
     @param type noise type as explained before
     @param gain noise gain
     */
    float process(float type, float gain)
    {
        // generate noise
        float noise = rand() % 10000 / 10000.0;
        
        // noisy type with highpass filter
         if (type == 0)
         {
             filter.setCoefficients(juce::IIRCoefficients::makeHighPass(sampleRate, 500.0, 5.0f));
             noise = filter.processSingleSampleRaw(noise);
             output = noise * gain;
         }
        
        // quiet type with lowpass filter
         else if (type == 1)
         {
             filter.setCoefficients(juce::IIRCoefficients::makeLowPass(sampleRate, 500.0, 5.0f));
             noise = filter.processSingleSampleRaw(noise);
             output = noise * gain;
         }
         
         return output;
     }

private:
    float output;           // output noise
    float gain;             // noise gain
    float sampleRate;       // sample rate
    juce::IIRFilter filter; // filter
    
   // juce::Random random;
};
