/*
  ==============================================================================

    TheSetOf5Strings.h
    Created: 18 Dec 2022 7:02:25pm
    Author:  Yining Xie

  ==============================================================================
*/

#pragma once
#include "MyOscillators.h"

/**
 This class combines 5 strings together, with one exactly same with input midi frequency, and the other two pairs of 2 strings that can be detuned, their frequencies are respectively:
 - string[2]: midi frequency
 - string[1] & string [3]: midi frequency +- detuned frequency
 - string[0] & string [4]: midi frequency +- 2 * detuned frequency
 It also introduces 2 different strike types:
 - pluck, like guitar and many of the kind; you can also choose to have it with or without delay - in some ways with or without echo
 - continuous - like violin though in this case it's just a rough simulation - way too dangerous for memory to add up vibrations as it should be in reality
 */
class TheSetOf5Strings
{
public:
    
    /// empty destructor function
    ~TheSetOf5Strings(){};

    /**
     set sample rate
     
     @param sr samplerate in Hz
     */
    void setSampleRate(float sr)
    {
        for (int i = 0; i < 5; i++)
        {
            sampleRate = sr;
            strings[i].setSampleRate(sampleRate);
        }
        delay.setSizeInSamples(2*sr);             // sets maximum size
        delay.setDelayTimeInSamples(sr * 1.3);  // sets specific delay time
        delay.setFeedback(0.0);
    }
    
    /**
     set fixed parameters
     
     @param waveV  wave velocity
     @param pluckP  pluck position
     @param N  resonance number
     */
    void setFixedParam(float waveV, float PluckP, float N)
    {
        // initialize each string
        for (int i = 0; i < 5; i++)
        {
            strings[i].setWaveVelocity(waveV);
            strings[i].setPluckPosition(PluckP);
            strings[i].setResonanceNumber(N);
        }
        
        // initialize decay time for the pluck situation
        decayTime = 0.0;
    }
    
    /**
     set frequencies - main frequency, detuned frequency and when needed - a free change of frequencies. It helps when you want to mimic a glide with parameter automation in DAW
     
     @param freq  main midi frequency
     @param detuneFreq  detuned frequency
     @param freeGlide  something to make frequency changeable from the basis of midi frequency
     */
    void setFrequencies(float freq, float detuneFreq, float freeGlide)
    {
        float newfreq = freq + freeGlide;
        
        for (int i = 0; i < 5; i++)
        {
            strings[i].setFundamentalFrequency(newfreq + (i-2) * detuneFreq);
        }
        
    }
    
    /**
     get gains for each (pair) of strings and decay rate for pluck situation
     
     @param g1  gain for string[2]
     @param g2  gain for string[1] and [3]
     @param g3  gain for string[0] and [4]
     @param dt  decay rate for pluck situation
     */
    void getParam(float g1, float g2, float g3, float dt)
    {
        
        gain[0] = g1;
        gain[1] = g2;
        gain[2] = g3;
        decayRate = dt;
    }
    
    /**
     select strike types and output the summed up displacement of 5 strings
     
     @param env  envelop for continuous situation
     @param type  strike type
     @param isDelay  whether or not to have delay for pluck
     */
    float process(float env, float type, float isDelay)
    {
        mix = 0.0;
        
        // basic output displacement
        for (int i = 0; i < 5; i++)
        {
            mix = mix + strings[i].process() * gain[abs(i-2)];
        }
        
        // pluck case
        if (type == 0.0)
        {
            // it decays by itself after a certain amount of time
            soundOfString = mix * exp (- M_PI * 1 * decayTime);
            decayTime = decayTime + decayRate / sampleRate;
            
            // need to track when the sound is off to set play to off in MySynthesiser.h
            tracker = exp (- M_PI * 1 * decayTime);
            
            // when there is delay
            if (isDelay == 1.0)
            {
                float delayedSample = delay.process(soundOfString);
                float ddelayedSample = delay.process(delayedSample);
                soundOfString = soundOfString + 0.75 * delayedSample + 0.5 * ddelayedSample;
                tracker = exp (- M_PI * 1 * (decayTime - 2.6));
            }
             
        // continuous strike case
        }
        else if (type == 1.0)
            // add an envelop to make sound better
            soundOfString = env * mix;
        
        // output sound of string
        return soundOfString;
    }
    
    /**
     function to get the tracked value as explained in pluck case
     */
    float getTracker()
    {
        return tracker;
    }
    
    
private:
    OhMyString strings[5];  // strings
    float sampleRate;       // sample rate
    float mix;              // basic sound of all strings
    float gain[3];          // gain
    float soundOfString;    // final sound with type chosen
    float decayRate;        // decay rate for pluck situation
    float decayTime;        // decay time for pluck situation
    DelayLine delay;        // delay
    float tracker;          // tracker as explained above
};
