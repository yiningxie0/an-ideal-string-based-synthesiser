

/*
  ==============================================================================

    MakeString.h
    Created: 9 Dec 2022 9:14:52pm
    Author:  Yining Xie

  ==============================================================================
*/

#pragma once

#include "MyOscillators.h"

/**
 Physical modelling of an ideal string that sounds differently when it's plucked at different positions
 Takes in sample rate, resonance number, wave velocity, pluck position, fundamental frequency
 Outputs displacement sample that makes sound
 
 Note that as far as it is a physical modelling, parameters except frequency are not able to change smoothly during the playing of a certain note, this is due to the physical function structures - and when playing an instrument in reality you are not able to change it physical parameters either. Nonetheless you can still change them between two notes.
 */
class OhMyString
{
public:
    
    /// destructor function
    ~OhMyString()
    {
        if (frequencies != nullptr)
            delete[] frequencies;
        if (coefficients != nullptr)
            delete[] coefficients;
        if (osc != nullptr)
            delete[] osc;
    };
    
    
    /**
     set sample rate and ensure any non-empty array pointers are deleted
     
     @param sr samplerate in Hz
     */
    void setSampleRate(float sr)
    {
        sampleRate = sr;
        
        if (frequencies != nullptr)
            delete[] frequencies;
        frequencies = new float[resonanceNumber];
        
        if (coefficients != nullptr)
            delete[] coefficients;
        coefficients = new float[resonanceNumber];
        
        if (osc != nullptr)
            delete[] osc;
        osc = new SinOsc[resonanceNumber];
    }
    
    
    
    /**
     take in resonance number of the string and preset pointer arrays of relevant coefficients
     
     @param _N resonance number
     */
    
    void setResonanceNumber(float N)
    {
        // take in resonance number
        resonanceNumber = N;
        
        // delete old pointer arrays and construct new ones according to resonance number
        if (frequencies != nullptr)
            delete[] frequencies;
        frequencies = new float[resonanceNumber];
        
        if (coefficients != nullptr)
            delete[] coefficients;
        coefficients = new float[resonanceNumber];
        
        if (osc != nullptr)
            delete[] osc;
        osc = new SinOsc[resonanceNumber];
        
        // calculate coefficients for each mode
        for (int i = 0; i < resonanceNumber; i++)
        {
            // set up resonance frequencies
            frequencies[i] = (i + 1) * fundamentalFreq;
            
            // the coeffcients in the mode equation
            coefficients[i] = 2 * sin(pluckPosition * waveVelocity * (i + 1) * M_PI / 2) / (pluckPosition * (1 - pluckPosition) * waveVelocity * waveVelocity * (i + 1) * (i + 1) * M_PI * M_PI /4);
            
            // the cosine parts in displacement equation: y = sum(C*cos(2*pi*fn*t))
            osc[i].setSampleRate(sampleRate);
            osc[i].setPhaseOffset(0.25);
            osc[i].setFrequency(frequencies[i]);
        }
        
        // set up gain for attack
        g = 0.0;
        
    }
    
    /**
     take in pluck position that would affect the timbre
     
     @param k pluck position
     */
    void setPluckPosition(float k)
    {
        pluckPosition = k;
        
        // recalculate coefficients for each mode
        for (int i = 0; i < resonanceNumber; i++)
        {
            coefficients[i] = 2 * sin(pluckPosition * waveVelocity * (i + 1) * M_PI / 2) / (pluckPosition * (1 - pluckPosition) * waveVelocity * waveVelocity * (i + 1) * (i + 1) * M_PI * M_PI /4);
        }
        
    }
    
    /**
     take in wave velocity that would affect the timbre
     
     @param c wave velocity
     */
    void setWaveVelocity(float c)
    {
        waveVelocity = c;
        
        // recalculate coefficients for each mode
        for (int i = 0; i < resonanceNumber; i++)
        {
            coefficients[i] = 2 * sin(pluckPosition * waveVelocity * (i + 1) * M_PI / 2) / (pluckPosition * (1 - pluckPosition) * waveVelocity * waveVelocity * (i + 1) * (i + 1) * M_PI * M_PI /4);
        }
    }

    /**
     take in foundamental frequency and calculate resonance frequencies
     
     @param f0 foundamental frequency in Hz
     */
    void setFundamentalFrequency(float f0)
    {
        fundamentalFreq = f0;
        
        // recalculate coefficients for each mode
        for (int i = 0; i < resonanceNumber; i++)
        {
            // calculate resonance frequencies
            frequencies[i] = (i + 1) * fundamentalFreq;
            
            // the coeffcients in the mode equation
            coefficients[i] = 2 * sin(pluckPosition * waveVelocity * (i + 1) * M_PI / 2) / (pluckPosition * (1 - pluckPosition) * waveVelocity * waveVelocity * (i + 1) * (i + 1) * M_PI * M_PI /4);
            
            // reset the frequency in cosine function too
            osc[i].setFrequency(frequencies[i]);
           
        }
    }
    
    /// Output diaplacement which makes soound
    float process()
    {
        
        float displacement = 0.0;
        
        // calculate displacemet
        for (int i = 0; i < resonanceNumber; i++)
        {
            displacement = displacement + coefficients[i] * osc[i].process();
        }
        
        // calculate gain factor
        float gain = (pluckPosition * (1 - pluckPosition) * waveVelocity * waveVelocity * M_PI * M_PI /4) / 2;
       
        // set up attack gain
        if (g < 1)
            g = g + 30 / sampleRate;
        
        // generate displacement that sounds continiously
        sample = g * gain * displacement;
        
        // output sample
        return sample;
    }
    
private:
    
    float sampleRate;                  // sample rate
    int resonanceNumber = 15;          // resonance number
    float fundamentalFreq;             // fundamental frequency
    float waveVelocity = 3.2;          // wave velocity
    float pluckPosition = 0.8;         // pluck position
    float sample;                      // output sample
    float g = 0.0;                     // attack gain
    
    // array pointers used in order to make the string changeable with number of resonance
    SinOsc* osc = nullptr;             // cosine funtion indicating time
    float* frequencies = nullptr;      // resonance frequencies
    float* coefficients = nullptr;     // coefficients for modes
   
    
};
