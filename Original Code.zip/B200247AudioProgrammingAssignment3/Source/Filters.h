/*
  ==============================================================================

    Filters.h
    Created: 18 Dec 2022 11:36:13pm
    Author:  Yining Xie

  ==============================================================================
*/

#pragma once
#include "MyOscillators.h"

/**
 A class for filters just to make the main cpp and headfiles neat
 It includes 3 situations accroding to user's need : no filter, lowpass filter and highpass filter
 When filters are implemented, their cutoff frequencies are able to change with a lfo, or stay a constant if the lfo frequecy is 0.
 Outputs original or filtered sample depending on type input
 */
class Filters
{
public:
    
    /// empty destructor function
    ~Filters(){};
    
    /**
     set sample rate
     
     @param sr samplerate in Hz
     */
    void setSampleRate(float sr)
    {
        sampleRate = sr;
        lfo.setSampleRate(sr);
    }
    
    /**
     set input parameters

     @param t filter type - 0 no filter, 1 highpass filter, 2 lowpass filter
     @param cutOffFreqMin mininum cutoff frequency
     @param cutOffR range of cutoff frequency change
     @param lfoFreq cutoff frequency lfo's frequency
     @param q filterQ
     */
    void set(float t, float cutOffFreqMin, float cutOffR, float lfoFreq, float q)
    {
        // save input parameters to class private members
        cutOffMin = cutOffFreqMin;
        cutOffRange = cutOffR;
        Q = q;
        lfo.setFrequency(lfoFreq);
        type = t;
    }
    
    /**
     process function
     
     @param sample sample to be processed
     */
    float process(float sample)
    {
        // set cutoff frequency
        float cutOffFreq = cutOffRange / 2 * lfo.process() + cutOffMin + cutOffRange / 2;
       
        // the case of highpass filter
        if (type == 1)
        {
            filter.setCoefficients(juce::IIRCoefficients::makeHighPass(sampleRate, cutOffFreq, Q));
            output = filter.processSingleSampleRaw(sample);
        }
        // the case of lowpass filter
        else if (type == 2)
        {
            filter.setCoefficients(juce::IIRCoefficients::makeLowPass(sampleRate, cutOffFreq, Q));
            output = filter.processSingleSampleRaw(sample);
        }
        // the case of no filter
        else if (type == 0)
            output = sample;
        
        // return output
        return output;
    }
    
private:
    float sampleRate;       // sample rate
    SinOsc lfo;             // lfo for cutoff frequency
    float output;           // output
    float cutOffMin;        // minimun cutoff frequency
    float cutOffRange;      // range of cutoff frequency
    float Q;                // filter Q
    juce::IIRFilter filter; // filter
    float type;             // filter type
};
