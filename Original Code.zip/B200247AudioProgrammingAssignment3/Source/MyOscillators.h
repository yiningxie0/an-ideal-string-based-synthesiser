//
//  MyOscillators.h
//  AudioProgrammingAssignment2
//
//  Created by Yining Xie
//

#ifndef MyOscillators_h
#define MyOscillators_h

/**
Oscillator class with three wave shapes (processSine, processSquare, processTriangle)

outputs the phase directly in the range: 0-1
*/
class Phasor
{
public:
    
    /// empty destructor function
    virtual ~Phasor() {};
    
    // Our parent oscillator class does the key things required for most oscillators:
    // -- handles phase
    // -- handles setters and getters for frequency and samplerate
    
    ///constructor
    void phasor(float sr, float freq, float _phaseOffset)
    {
        sampleRate = sr;
        frequency = freq;
        phaseOffset = _phaseOffset;
        phaseDelta = frequency / sampleRate;
        phase = phaseOffset;
    }
    
    /**
     set sample rate
     
     @param SR samplerate in Hz
     */
    void setSampleRate(float sr)
    {
        sampleRate = sr;
    }
    
    /**
     set the oscillator frequency
     
     @param freq oscillator frequency in Hz
     */
    void setFrequency(float freq)
    {
        frequency = freq;
        phaseDelta = frequency / sampleRate;
    }
    
    /**
     set the oscillator phase offset
     
     @param _phaseOffset oscillator phase offset between 0-1
     */
    void setPhaseOffset(float _phaseOffset)
    {
        phaseOffset = _phaseOffset;
        phase = phaseOffset;
    }

    /// update the phase and output the next sample from the oscillator
    float process()
    {
        phase += phaseDelta;
        
        if (phase > 1.0f)
            phase -= 1.0f;
        
        return output(phase);
    }
    
    /// this function is the one that we will replace in the classes that inherit from Phasor
    virtual float output(float p)
    {
        return p;
    }
    

    
private:
    float phase = 0.0f;          // phase value
    float phaseDelta;            // step of phase
    float frequency;             // frequency
    float sampleRate;            // sample rate
    
    float phaseOffset = 0.0;     // phase offset, could be used for phase modulation
};

/**
 Sine Oscillator built on Phasor base class
 */
class SinOsc : public Phasor
{
    float output(float p) override
    {
        return sin(2 * 3.141593 * p);
    }
};


/**
 Squarewave Oscillator built on Phasor base class
 
 Includes setPulseWidth to change the waveform shape
 */
class SquareOsc : public Phasor
{
public:
    float output(float p) override
    {
        float outVal = 0.5;
        if (p > pulseWidth)
            outVal = -0.5;
        return outVal;
    }
    
    /// set square wave pulse width (0-1))
    void setPulseWidth(float pw)
    {
        pulseWidth = pw;
    }
private:
    float pulseWidth = 0.5f;
};

/**
 Triangle oscillator built on Phasor base class
 
 Note that the output is quiet by default: ±0.25
 */
class TriOsc : public Phasor
{
    float output(float p) override
    {
        return fabs(p - 0.5) - 0.25;
    }
};
#endif /* MyOscillators_h */
