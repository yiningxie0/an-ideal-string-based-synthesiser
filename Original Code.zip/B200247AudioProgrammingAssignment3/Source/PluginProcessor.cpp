/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
B200247AudioProgrammingAssignment3AudioProcessor::B200247AudioProgrammingAssignment3AudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                     #endif
                       ),
#endif
parameters (* this , nullptr , "ParamTreeID", {
// ParameterLayout initialisation to go here .
    // parameters for strings, as named or explained in the class
    std::make_unique<juce::AudioParameterChoice>("strikeType", "Strike Type", juce::StringArray("pluck", "continuous"), 0),
    std::make_unique<juce::AudioParameterChoice>("forPluckIsDelay", "ForPluckIsDelay", juce::StringArray("off", "on"), 0),
    std::make_unique<juce::AudioParameterFloat>("centreStringGain", "CentreStringGain", 0.0f, 1.0f, 1.0f),
    std::make_unique<juce::AudioParameterFloat>("detuneStringGain1", "DetuneStringGain1", 0.0f, 1.0f, 0.8f),
    std::make_unique<juce::AudioParameterFloat>("detuneStringGain2", "DetuneStringGain2", 0.0f, 1.0f, 0.6f),
    std::make_unique<juce::AudioParameterFloat>("stringDetuneParam", "StringDetuneParam", 0.0f, 20.0f, 0.0f),
    std::make_unique<juce::AudioParameterInt>("stringResonanceNumber", "StringResonancNumber", 1, 15, 15),
    std::make_unique<juce::AudioParameterFloat>("stringWaveVelocity", "StringWaveVelocity", 0.1f, 50.0f, 3.0f),
    std::make_unique<juce::AudioParameterFloat>("stringPluckPosition", "StringPluckPosition", 0.001f, 0.999f, 0.9f),
    std::make_unique<juce::AudioParameterFloat>("decayRate", "DecayRate", 0.0f, 2.0f, 1.0f),
    std::make_unique<juce::AudioParameterFloat>("freeGlide", "FreeGlide", 0.0f, 200.0f, 0.0f),
    
    // parameters for oscss, as named or explained in the class
    std::make_unique<juce::AudioParameterChoice>("oscsType", "OscsType", juce::StringArray("Sine", "Triangle", "Square", "Sawtooth"), 0),
    std::make_unique<juce::AudioParameterFloat>("oscsDetune", "OscsDetune", 0.0f, 10.0f, 0.0f),
    std::make_unique<juce::AudioParameterFloat>("oscsGain", "OscsGain", 0.0f, 1.0f, 0.0f),
    
    // parameters for noise, as named or explained in the class
    std::make_unique<juce::AudioParameterChoice>("noiseType", "NoiseType", juce::StringArray("Noisy", "Quiet"), 1),
    std::make_unique<juce::AudioParameterFloat>("noiseGain", "NoiseGain", 0.0f, 1.0f, 0.0f),
    
    // parameters for filters, as named or explained in the class
    std::make_unique<juce::AudioParameterChoice>("filterType", "FilterType", juce::StringArray("None", "HighPass", "LowPass"), 0),
    std::make_unique<juce::AudioParameterFloat>("filterCutoffMin", "FilterCutoffMin", 50.0f, 1000.0f, 500.0f),
    std::make_unique<juce::AudioParameterFloat>("filterCutoffRange", "FilterCutoffRange", 10.0f, 100.0f, 50.0f),
    std::make_unique<juce::AudioParameterFloat>("filterLfoFrequency", "FilterLfoFrequency", 0.0f, 5.0f, 20.0f),
    std::make_unique<juce::AudioParameterFloat>("filterQ", "FilterQ", 0.1f, 50.0f, 5.0f),
    
    // parameters for left channel gain and delay
    std::make_unique<juce::AudioParameterFloat>("leftDelayTime", "LeftDelayTime", 0.0f, 2.0f, 0.0f),
    std::make_unique<juce::AudioParameterFloat>("leftGain", "LeftGain", 0.0f, 1.0f, 0.5f),
    
    // parameters for right channel gain and delay
    std::make_unique<juce::AudioParameterFloat>("rightDelayTime", "RightDelayTime", 0.0f, 2.0f, 0.0f),
    std::make_unique<juce::AudioParameterFloat>("rightGain", "RightGain", 0.0f, 1.0f, 0.5f),
   
    // parameters for reverb
    std::make_unique<juce::AudioParameterFloat>("reverbDryLevel", "ReverbDryLevel", 0.0f, 1.0f, 0.4f),
    std::make_unique<juce::AudioParameterFloat>("reverbWetLevel", "ReverbWetLevel", 0.0f, 1.0f, 0.33f),
    std::make_unique<juce::AudioParameterFloat>("reverbRoomSize", "ReverbRoomSize", 0.0f, 1.0f, 0.5f),
} )


{
    // point our float pointer at the parameter using the id
    // parameters for strings
    stringDetuneParam = parameters.getRawParameterValue ("stringDetuneParam");
    stringResonanceNumber = parameters.getRawParameterValue ("stringResonanceNumber");
    stringWaveVelocity = parameters.getRawParameterValue ("stringWaveVelocity");
    stringPluckPosition = parameters.getRawParameterValue ("stringPluckPosition");
    strikeType = parameters.getRawParameterValue ("strikeType");
    decayRate = parameters.getRawParameterValue ("decayRate");
    forPluckIsDelay = parameters.getRawParameterValue ("forPluckIsDelay");
    centreStringGain = parameters.getRawParameterValue ("centreStringGain");
    detuneStringGain1 = parameters.getRawParameterValue ("detuneStringGain1");
    detuneStringGain2 = parameters.getRawParameterValue ("detuneStringGain2");
    freeGlide = parameters.getRawParameterValue ("freeGlide");
    
    // parameters for oscs
    oscsType = parameters.getRawParameterValue ("oscsType");
    oscsDetune = parameters.getRawParameterValue ("oscsDetune");
    oscsGain = parameters.getRawParameterValue ("oscsGain");
    
    // parameters for noise
    noiseType = parameters.getRawParameterValue ("noiseType");
    noiseGain = parameters.getRawParameterValue ("noiseGain");
    
    // parameters for filter
    filterType = parameters.getRawParameterValue ("filterType");
    filterCutoffMin = parameters.getRawParameterValue ("filterCutoffMin");
    filterCutoffRange = parameters.getRawParameterValue ("filterCutoffRange");
    filterLfoFrequency = parameters.getRawParameterValue ("filterLfoFrequency");
    filterQ = parameters.getRawParameterValue ("filterQ");
    
    // parameters for decay and gain each channel
    leftDelayTime = parameters.getRawParameterValue ("leftDelayTime");
    leftGain = parameters.getRawParameterValue ("leftGain");
    rightDelayTime = parameters.getRawParameterValue ("rightDelayTime");
    rightGain = parameters.getRawParameterValue ("rightGain");
    
    // parameters for reverb
    reverbDryLevel = parameters.getRawParameterValue ("reverbDryLevel");
    reverbWetLevel = parameters.getRawParameterValue ("reverbWetLevel");
    reverbRoomSize = parameters.getRawParameterValue ("reverbRoomSize");
    
    // connect with synth class
    for (int i = 0; i < voiceCount; i++)
    {
        synth.addVoice( new MySynthVoice () );
    }
    
    synth.addSound( new MySynthSound() );
    
    for (int i =0; i < voiceCount ; i ++)
    {
    MySynthVoice* v = dynamic_cast<MySynthVoice*>( synth.getVoice(i));
    v->setParameterPointers(stringDetuneParam, stringResonanceNumber, stringWaveVelocity, stringPluckPosition, strikeType, decayRate, forPluckIsDelay, centreStringGain, detuneStringGain1, detuneStringGain2, freeGlide, oscsType, oscsDetune, oscsGain, noiseGain, noiseType, filterType, filterCutoffMin, filterCutoffRange, filterLfoFrequency, filterQ);
    }
}

B200247AudioProgrammingAssignment3AudioProcessor::~B200247AudioProgrammingAssignment3AudioProcessor()
{
}

//==============================================================================
const juce::String B200247AudioProgrammingAssignment3AudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool B200247AudioProgrammingAssignment3AudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool B200247AudioProgrammingAssignment3AudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool B200247AudioProgrammingAssignment3AudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double B200247AudioProgrammingAssignment3AudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int B200247AudioProgrammingAssignment3AudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int B200247AudioProgrammingAssignment3AudioProcessor::getCurrentProgram()
{
    return 0;
}

void B200247AudioProgrammingAssignment3AudioProcessor::setCurrentProgram (int index)
{
}

const juce::String B200247AudioProgrammingAssignment3AudioProcessor::getProgramName (int index)
{
    return {};
}

void B200247AudioProgrammingAssignment3AudioProcessor::changeProgramName (int index, const juce::String& newName)
{
}

//==============================================================================
void B200247AudioProgrammingAssignment3AudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    // set up and connect synth class
    synth.setCurrentPlaybackSampleRate(sampleRate);
    
    for (int i =0; i < voiceCount ; i ++)
    {
    MySynthVoice* v = dynamic_cast<MySynthVoice*>( synth.getVoice(i));
    v->init(sampleRate);
    }
    
    // get sample rate
    sr = getSampleRate();
   
    // set delay max size
    delay[0].setSizeInSamples(5 * sr);
    delay[1].setSizeInSamples(5 * sr);
 
    
    
}

void B200247AudioProgrammingAssignment3AudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool B200247AudioProgrammingAssignment3AudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    juce::ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    // Some plugin hosts, such as certain GarageBand versions, will only
    // load plugins that support stereo bus layouts.
    if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void B200247AudioProgrammingAssignment3AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
   
    // functions in synth
    synth.renderNextBlock(buffer, midiMessages, 0, buffer.getNumSamples() );
    
    // set reverb parameters
    juce::Reverb::Parameters reverbParams;
    reverbParams.dryLevel = *reverbDryLevel;
    reverbParams.wetLevel = *reverbWetLevel;
    reverbParams.roomSize = *reverbRoomSize;
    reverb.setParameters(reverbParams);
    
    // set specific delay time
    delay[0].setDelayTimeInSamples(sr * *leftDelayTime);
    delay[1].setDelayTimeInSamples(sr * *rightDelayTime);
    
    // get channels
    int numSamples = buffer . getNumSamples ();
    auto * leftChannel = buffer . getWritePointer (0);
    auto * rightChannel = buffer . getWritePointer (1);
    
    //dsp loop
    for (int i = 0; i < numSamples; i++)
    {
        // no delay when delay time is set to 0, else do delay
        if (*leftDelayTime == 0.0)
            leftChannel[i] = *leftGain * leftChannel[i];
        else
            leftChannel[i] = *leftGain * delay[0].process( leftChannel[i] );
        
        if (*rightDelayTime == 0.0)
            rightChannel[i] = *rightGain * rightChannel[i];
        else
            rightChannel[i] = *rightGain * delay[1].process( rightChannel[i] );
    }
    
    // do reverb
    reverb.processStereo(leftChannel, rightChannel, numSamples);
}

//==============================================================================
bool B200247AudioProgrammingAssignment3AudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

juce::AudioProcessorEditor* B200247AudioProgrammingAssignment3AudioProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor (*this);
}

//==============================================================================
void B200247AudioProgrammingAssignment3AudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);

}

void B200247AudioProgrammingAssignment3AudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState.get() != nullptr)
    {
        if (xmlState->hasTagName (parameters.state.getType()))
        {
            parameters.replaceState (juce::ValueTree::fromXml (*xmlState));
        }
    }
}

//==============================================================================
// This creates new instances of the plugin..
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new B200247AudioProgrammingAssignment3AudioProcessor();
}
